print('script_server:hello world')

